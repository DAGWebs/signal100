<?php 
	session_start();
	function url($url) {
		header("Location: " . $url);
	}
	if(isset($_POST['submit'])) {
		$username = $_POST['username'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$confirmPassword = $_POST['confirmPassword'];

		echo "Your username is: <strong>" . $username . "</strong>";
		echo "<br>";
		echo "<br>";
		echo "Your email is: <strong>" . $email . "</strong>";
		echo "<br>";
		echo "<br>";
		echo "Your Password is: <strong>" . $password . "</strong>";
		echo "<br>";
		echo "<br>";
		echo "Your Confirmed Password is: <strong>" . $confirmPassword . "</strong>";
		echo "<br>";
		echo "<br>";
	} else {
		$_SESSION["Nosubmit"] = "Submit button was not used";
		url("../../register.php?Submit_Button=FALSE");

	}